
public interface EmployeeService {
public Employee getDetails(int empId);
}
