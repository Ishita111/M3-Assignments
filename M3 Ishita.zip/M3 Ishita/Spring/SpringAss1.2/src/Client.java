import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client 
{
	public static void main(String[] args) 
	{
		ApplicationContext context= new ClassPathXmlApplicationContext("helloBean.xml");
		
		Employee emp=(Employee)context.getBean("hello");
		Employee2 emp2=(Employee2)context.getBean("hello1");

		System.out.println("Ishita");
		System.out.println("Employee details...");
		System.out.println("----------------------------------------------------------");
		System.out.println("Employee: [empId: "+emp.getEmployeeId()+", empName: "+emp.getEmployeeName()+", empBusiness Unit: "+emp.getBussinessUnit());
		System.out.println("sbu details= SBU [sbuId: "+emp2.getSbuId()+", sbuName: "+emp2.getSbuName()+", sbuBusiness Unit: "+emp2.getSbuHead());
	}

}