import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

public static void main(String[] args) {
ApplicationContext context=new ClassPathXmlApplicationContext("helloBean.xml");
		
Employee obj= (Employee) context.getBean("hello");
			
System.out.println("Employee details....");

System.out.println("ID: "+obj.getEmployeeId());
System.out.println("Name: "+obj.getEmployeeName());
System.out.println("Salary: "+obj.getSalary());
System.out.println("Age: "+obj.getAge());
System.out.println("Bussiness Unit: "+obj.getBussinessUnit());
}

}
